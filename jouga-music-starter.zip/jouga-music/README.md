# JOÜGA MUSIC

Starter project untuk web music responsif dengan tema dark AMOLED, aksen lime/purple, pencarian API, player audio, mini-player, favorit, playlist lokal, riwayat, dan fondasi PWA.

## Kebutuhan
- Node.js 20 atau lebih baru
- Koneksi internet untuk mengakses API pencarian/pemutar dan Google Fonts

## Menjalankan secara lokal
1. Ekstrak ZIP lalu buka folder `jouga-music`.
2. Jalankan `npm install`.
3. Salin `.env.example` menjadi `.env`.
4. Isi `SPOTIFY_API_KEY` dengan key API yang valid.
5. Jalankan `npm run dev`.
6. Buka alamat Vite yang tampil di terminal (umumnya `http://localhost:5173`).

Backend API berjalan di `http://localhost:3000`. Endpoint rahasia tidak dipanggil langsung dari browser.

## Build produksi
```bash
npm install
cp .env.example .env
# edit .env, isi SPOTIFY_API_KEY
npm run build
npm start
```
Buka `http://localhost:3000`.

## Endpoint yang dipakai
- `GET /api/search?q=<query>` meneruskan ke `spotifysearch?query=<query>&key=<server key>`.
- `GET /api/play?q=<query>` meneruskan ke `spotifyplay?q=<query>&key=<server key>`.

Normalisasi search mengikuti contoh yang diberikan: `data[]` dengan `name`, `artist`, `duration`, `cover`, `tid`, `spotifyUrl`. Playback mengikuti `result.success` dan `result.result.download`, serta metadata di `result.result`.

## Batasan awal yang diketahui
- API search/play diuji berdasarkan contoh JSON dari pemilik proyek, belum diverifikasi live.
- Playback meminta URL berdasarkan gabungan judul + artis. Endpoint yang diberikan tidak menerima track ID pada contoh, jadi API bisa memilih versi yang berbeda dari baris hasil pencarian.
- URL download dari contoh terlihat bertanda tangan dan memiliki masa berlaku. URL tersebut dipakai langsung oleh elemen audio browser; penyedia bisa menolak hotlink/CORS, mengubah format, atau membuat URL kedaluwarsa. Jika audio tidak bisa diputar, periksa apakah URL memang berupa audio yang didukung browser dan diizinkan untuk streaming web.
- Lagu demo di Home hanya placeholder visual, tidak ada audio demo.
- Favorit, playlist, dan riwayat tersimpan di `localStorage` pada perangkat/browser yang sama. Tidak ada akun/login atau sinkronisasi cloud.
- PWA shell dicache, tetapi API dan audio tidak dicache untuk menghindari menyimpan audio sementara. Untuk installable PWA pada produksi, gunakan HTTPS.
- Lirik belum disambungkan karena endpoint lirik belum diberikan.
- API key yang pernah ditempelkan di chat sebaiknya dirotasi jika itu key aktif, lalu masukkan key baru hanya di `.env`.
- Gunakan sumber audio hanya jika kamu memiliki hak/izin yang sesuai dan patuhi ketentuan penyedia layanan.

## Rekomendasi deploy
Untuk pemula, gunakan VPS kecil dengan Node.js 20+ dan HTTPS (Caddy/Nginx). Vercel juga bisa digunakan, tetapi endpoint audio bertanda tangan dan batas waktu serverless perlu diuji. Jangan commit `.env`.
